#include <stdio.h>
#include <stdlib.h>  // for system()
#include <stdint.h>  // for size_t
#include <unistd.h>  // for close()
#include <arpa/inet.h>  // for htonl()
#include <string.h>  // for memcpy
#include <openssl/crypto.h>  // for OPENSSL_free() & OPENSSL_zalloc()

#include "rsa_decrypt.h"
#include "rsa_encrypt.h"
#include "net_utils.h"

#define SERVER_PORT 90001
#define SERVER_HOST "127.0.0.1"

static const unsigned char msg[] =
    "To be, or not to be, that is the question,\n"
    "Whether tis nobler in the minde to suffer\n"
    "The slings and arrowes of outragious fortune,\n"
    "Or to take Armes again in a sea of troubles";

int main(void) {
    OSSL_LIB_CTX *libctx = NULL;
    // MESSAGES
    unsigned char *encrypted = NULL;
    size_t encrypted_len = 0;
    unsigned char *decrypted = NULL;
    size_t decrypted_len = 0;

    // CLIENT ENCRYPTION KEYS
    unsigned char *cli_priv_enc_key = NULL;
    size_t cli_priv_enc_key_len = 0;
    unsigned char *cli_pub_enc_key = NULL;
    size_t cli_pub_enc_key_len = 0;
    // CLIENT SIGNATURE KEYS
    unsigned char *cli_priv_sig_key = NULL;
    size_t cli_priv_sig_key_len = 0;
    unsigned char *cli_pub_sig_key = NULL;
    size_t cli_pub_sig_key_len = 0;

    // SERVER ENCRYPTION KEYS
    unsigned char *ser_pub_enc_key = NULL;
    size_t ser_pub_enc_key_len = 0;
    // SERVER SIGNATURE KEYS
    unsigned char *ser_pub_sig_key = NULL;
    size_t ser_pub_sig_key_len = 0;

    int server_sock = -1;
    int ret = EXIT_FAILURE;

    // CONNECT TO THE SERVER
    server_sock = connect_to_server(SERVER_HOST, SERVER_PORT);
    if (server_sock < 0) {
        fprintf(stderr, "Client: Failed to connect to server.\n");
        goto cleanup;
    }
    printf("Client: Connected to server.\n");

    // RUN THE SCRIPT to generate client encryption keys 
    printf("Client: Generating encryption keys...\n");
    if (system("./scripts/client_generate_encryption_keys.sh") != 0) {
        fprintf(stderr, "Client: Failed to generate encryption keys.\n");
        goto cleanup;
    }
    printf("Server: Encryption keys generated successfully.\n");

    // RUN THE SCRIPT to generate client signature keys
    printf("Server: Generating signature keys...\n");
    if (system("./scripts/client_generate_signature_keys.sh") != 0) {
        fprintf(stderr, "Client: Failed to generate signature keys.\n");
        goto cleanup;
    }

    // ENCRYPT THE MESSAGE
    if (!do_encrypt(libctx, msg, sizeof(msg) - 1, &encrypted, &encrypted_len)) {
        fprintf(stderr, "Encryption failed.\n");
        goto cleanup;
    }
    printf("Client: Encrypted message.\n");

    // SEND THE ENCRYPTED MESSAGE LENGTH by first
    uint32_t net_len = htonl((uint32_t)encrypted_len);  // converting from the host byte order to the network byte order to send
    if (send_all(server_sock, &net_len, sizeof(net_len)) != sizeof(net_len)) {
        fprintf(stderr, "Failed to send message length.\n");
        goto cleanup;
    }
    printf("Client: Sent encrypted message length to server.\n");

    // SEND THE ENCRYHPTED MESSAGE to the server
    if (send_all(server_sock, encrypted, encrypted_len) != (ssize_t)encrypted_len) {
        fprintf(stderr, "Failed to send encrypted data.\n");
        goto cleanup;
    }
    printf("Client: Sent encrypted message to server.\n");
    ret = EXIT_SUCCESS;

cleanup:
    if (server_sock >= 0)
        close(server_sock);
    if (encrypted)
        OPENSSL_free(encrypted);
    return ret;
}
