#include "./cli_enc_keys/cli_pub_enc_key.h"
#ifdef CLIENT_BUILD
#include "./cli_enc_keys/cli_priv_enc_key.h"
#endif

#include "./ser_enc_keys/ser_pub_enc_key.h"
#ifdef SERVER_BUILD
#include "./ser_enc_keys/ser_priv_enc_key.h"
#endif

#include "./cli_sig_keys/cli_pub_sig_key.h"
#ifdef CLIENT_BUILD
#include "./cli_sig_keys/cli_priv_sig_key.h"
#endif

#include "./ser_sig_keys/ser_pub_sig_key.h"
#ifdef SERVER_BUILD
#include "./ser_sig_keys/ser_priv_sig_key.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <openssl/err.h>
#include <openssl/decoder.h>
#include "rsa_common.h"

/* Helper function to load an EVP_PKEY from DER-encoded data */
static EVP_PKEY *get_key_from_der(const unsigned char *der, size_t der_len,
                                  OSSL_LIB_CTX *libctx, const char *propq,
                                  int is_public)
{
    OSSL_DECODER_CTX *dctx = NULL;
    EVP_PKEY *pkey = NULL;
    int selection;

    if (is_public)
        selection = EVP_PKEY_PUBLIC_KEY;
    else {
#ifdef SERVER_BUILD
        selection = EVP_PKEY_KEYPAIR;
#else
        fprintf(stderr, "Private key not available in CLIENT build.\n");
        return NULL;
#endif
    }

    dctx = OSSL_DECODER_CTX_new_for_pkey(&pkey, "DER", NULL, "RSA",
                                         selection, libctx, propq);
    if (dctx == NULL) {
        fprintf(stderr, "Failed to create decoder context.\n");
        return NULL;
    }

    {
        const unsigned char *data = der;
        size_t data_len = der_len;
        if (!OSSL_DECODER_from_data(dctx, &data, &data_len)) {
            fprintf(stderr, "Failed to decode DER data.\n");
            OSSL_DECODER_CTX_free(dctx);
            return NULL;
        }
    }

    OSSL_DECODER_CTX_free(dctx);
    return pkey;
}

/* Retrieve Server Encryption Key */
EVP_PKEY *get_ser_enc_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public)
{
    if (is_public)
        return get_key_from_der(ser_pub_enc_der, sizeof(ser_pub_enc_der),
                                libctx, propq, is_public);
#ifdef SERVER_BUILD
    else
        return get_key_from_der(ser_priv_enc_der, sizeof(ser_priv_enc_der),
                                libctx, propq, is_public);
#else
    else {
        fprintf(stderr, "Private key not available in CLIENT build.\n");
        return NULL;
    }
#endif
}

/* Retrieve Server Signature Key */
EVP_PKEY *get_ser_sig_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public)
{
    if (is_public)
        return get_key_from_der(ser_pub_sig_der, sizeof(ser_pub_sig_der),
                                libctx, propq, is_public);
#ifdef SERVER_BUILD
    else
        return get_key_from_der(ser_priv_sig_der, sizeof(ser_priv_sig_der),
                                libctx, propq, is_public);
#else
    else {
        fprintf(stderr, "Private key not available in CLIENT build.\n");
        return NULL;
    }
#endif
}

/* Retrieve Client Encryption Key */
EVP_PKEY *get_cli_enc_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public)
{
    if (is_public)
        return get_key_from_der(cli_pub_enc_der, sizeof(cli_pub_enc_der),
                                libctx, propq, is_public);
#ifdef CLIENT_BUILD
    else
        return get_key_from_der(cli_priv_enc_der, sizeof(cli_priv_enc_der),
                                libctx, propq, is_public);
#else
    else {
        fprintf(stderr, "Private key not available in SERVER build.\n");
        return NULL;
    }
#endif
}

/* Retrieve Client Signature Key */
EVP_PKEY *get_cli_sig_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public)
{
    if (is_public)
        return get_key_from_der(cli_pub_sig_der, sizeof(cli_pub_sig_der),
                                libctx, propq, is_public);
#ifdef CLIENT_BUILD
    else
        return get_key_from_der(cli_priv_sig_der, sizeof(cli_priv_sig_der),
                                libctx, propq, is_public);
#else
    else {
        fprintf(stderr, "Private key not available in SERVER build.\n");
        return NULL;
    }
#endif
}

/* Set optional parameters for OAEP padding */
void set_optional_params(OSSL_PARAM *p, const char *propq)
{
    static unsigned char label[] = "label";

    *p++ = OSSL_PARAM_construct_utf8_string(OSSL_ASYM_CIPHER_PARAM_PAD_MODE,
                                             OSSL_PKEY_RSA_PAD_MODE_OAEP, 0);
    *p++ = OSSL_PARAM_construct_octet_string(OSSL_ASYM_CIPHER_PARAM_OAEP_LABEL,
                                              label, sizeof(label));
    *p++ = OSSL_PARAM_construct_utf8_string(OSSL_ASYM_CIPHER_PARAM_OAEP_DIGEST,
                                             "SHA256", 0);
    if (propq != NULL)
        *p++ = OSSL_PARAM_construct_utf8_string(OSSL_ASYM_CIPHER_PARAM_OAEP_DIGEST_PROPS,
                                                 (char *)propq, 0);
    *p = OSSL_PARAM_construct_end();
}

/* Get Server Public Encryption Key DER */
const unsigned char *get_ser_pub_enc_key(size_t *len)
{
    if (len)
        *len = sizeof(ser_pub_enc_der);
    return ser_pub_enc_der;
}

#ifdef SERVER_BUILD
/* Get Server Private Encryption Key DER */
const unsigned char *get_ser_priv_enc_key(size_t *len)
{
    if (len)
        *len = sizeof(ser_priv_enc_der);
    return ser_priv_enc_der;
}
#endif

/* Get Client Public Encryption Key DER */
const unsigned char *get_cli_pub_enc_key(size_t *len)
{
    if (len)
        *len = sizeof(cli_pub_enc_der);
    return cli_pub_enc_der;
}

#ifdef CLIENT_BUILD
/* Get Client Private Encryption Key DER */
const unsigned char *get_cli_priv_enc_key(size_t *len)
{
    if (len)
        *len = sizeof(cli_priv_enc_der);
    return cli_priv_enc_der;
}
#endif

/* Get Server Public Signature Key DER */
const unsigned char *get_ser_pub_sig_key(size_t *len)
{
    if (len)
        *len = sizeof(ser_pub_sig_der);
    return ser_pub_sig_der;
}

#ifdef SERVER_BUILD
/* Get Server Private Signature Key DER */
const unsigned char *get_ser_priv_sig_key(size_t *len)
{
    if (len)
        *len = sizeof(ser_priv_sig_der);
    return ser_priv_sig_der;
}
#endif

/* Get Client Public Signature Key DER */
const unsigned char *get_cli_pub_sig_key(size_t *len)
{
    if (len)
        *len = sizeof(cli_pub_sig_der);
    return cli_pub_sig_der;
}

#ifdef CLIENT_BUILD
/* Get Client Private Signature Key DER */
const unsigned char *get_cli_priv_sig_key(size_t *len)
{
    if (len)
        *len = sizeof(cli_priv_sig_der);
    return cli_priv_sig_der;
}
#endif
