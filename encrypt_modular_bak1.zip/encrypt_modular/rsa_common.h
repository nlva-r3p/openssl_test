#ifndef RSA_COMMON_H
#define RSA_COMMON_H

#include <openssl/evp.h>
#include <openssl/core_names.h>
#include <openssl/params.h>

/* Get a public or private key from DER format data */
EVP_PKEY *get_ser_enc_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public);
EVP_PKEY *get_ser_sig_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public);
EVP_PKEY *get_cli_enc_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public);
EVP_PKEY *get_cli_sig_key(OSSL_LIB_CTX *libctx, const char *propq, int is_public);

void set_optional_params(OSSL_PARAM *p, const char *propq);

/* Get the server public encryption key in DER format */
const unsigned char *get_ser_pub_enc_key(size_t *len);
/* Get the server private encryption key in DER format (only available in SERVER_BUILD) */
#ifdef SERVER_BUILD
const unsigned char *get_ser_priv_enc_key(size_t *len);
#endif
/* Get the client public encryption key in DER format */
const unsigned char *get_cli_pub_enc_key(size_t *len);
/* Get the client private encryption key in DER format (only available in CLIENT_BUILD) */
#ifdef CLIENT_BUILD
const unsigned char *get_cli_priv_enc_key(size_t *len);
#endif

/* Get the server public signature key in DER format */
const unsigned char *get_ser_pub_sig_key(size_t *len);
/* Get the server private signature key in DER format (only available in SERVER_BUILD) */
#ifdef SERVER_BUILD
const unsigned char *get_ser_priv_sig_key(size_t *len);
#endif
/* Get the client public signature key in DER format */
const unsigned char *get_cli_pub_sig_key(size_t *len);
/* Get the client private signature key in DER format (only available in CLIENT_BUILD) */
#ifdef CLIENT_BUILD
const unsigned char *get_cli_priv_sig_key(size_t *len);
#endif

#endif /* RSA_COMMON_H */