#include <stdio.h>
#include <stdlib.h>  // for system()
#include <stdint.h>  // for size_t
#include <unistd.h>  // for close()
#include <arpa/inet.h>  // for htonl()
#include <string.h>  // for memcpy
#include <openssl/crypto.h>  // for OPENSSL_free() & OPENSSL_zalloc() 

#include "rsa_decrypt.h"
#include "rsa_common.h"  // for get_public_key_der()
#include "net_utils.h"

#define SERVER_PORT 90001

int main(void) {
    OSSL_LIB_CTX *libctx = NULL;
    // MESSAGES
    unsigned char *encrypted = NULL;
    size_t encrypted_len = 0;
    unsigned char *decrypted = NULL;
    size_t decrypted_len = 0;

    // CLIENT ENCRYPTION KEYS
    unsigned char *cli_priv_enc_key = NULL;
    size_t cli_priv_enc_key_len = 0;
    unsigned char *cli_pub_enc_key = NULL;
    size_t cli_pub_enc_key_len = 0;
    // CLIENT SIGNATURE KEYS
    unsigned char *cli_priv_sig_key = NULL;
    size_t cli_priv_sig_key_len = 0;
    unsigned char *cli_pub_sig_key = NULL;
    size_t cli_pub_sig_key_len = 0;

    // SERVER ENCRYPTION KEYS
    unsigned char *ser_pub_enc_key = NULL;
    size_t ser_pub_enc_key_len = 0;
    // SERVER SIGNATURE KEYS
    unsigned char *ser_pub_sig_key = NULL;
    size_t ser_pub_sig_key_len = 0;

    int server_sock = -1, client_sock = -1;
    int ret = EXIT_FAILURE;
    
    // CREATE A SERVER socket
    server_sock = create_server_socket(SERVER_PORT);
    if (server_sock < 0) {
        fprintf(stderr, "Server: Failed to create socket.\n");
        goto cleanup;
    }
    printf("Server: Created server socket.\n");

    // ACCEPT A CLIENT connection
    printf("Server: Waiting for connection on port %d...\n", SERVER_PORT);
    client_sock = accept_client(server_sock);
    if (client_sock < 0) {
        fprintf(stderr, "Server: Failed to accept client connection.\n");
        goto cleanup;
    }
    printf("Server: Accepted client connection.\n");

    // RUN THE SCRIPT to generate server encryption keys 
    printf("Server: Generating encryption keys...\n");
    if (system("./scripts/server_generate_encryption_keys.sh") != 0) {
        fprintf(stderr, "Server: Failed to generate encryption keys.\n");
        goto cleanup;
    }
    printf("Server: Encryption keys generated successfully.\n");

    // RUN THE SCRIPT to generate server signature keys
    printf("Server: Generating signature keys...\n");
    if (system("./scripts/server_generate_signature_keys.sh") != 0) {
        fprintf(stderr, "Server: Failed to generate signature keys.\n");
        goto cleanup;
    }

    // RECEIVE THE ENCRYPTED MESSAGE LENGTH from client, and
    uint32_t net_len = 0;
    if (recv_all(client_sock, &net_len, sizeof(net_len)) != sizeof(net_len)) {
        fprintf(stderr, "Server: Failed to receive message length.\n");
        goto cleanup;
    }
    printf("Server: Received encrypted message length from client.\n");
    encrypted_len = ntohl(net_len);  // after received, convert network byte order to host byte order

    /*
        ALLOCATE MEMORY FOR ENCRYPTED MESSAGE using the encrypted_len
        OPENSSL_zalloc() calls memset() to zero the memory before returning.
        Return a pointer to allocated memory or NULL on error.
    */
    encrypted = OPENSSL_zalloc(encrypted_len);
    if (encrypted == NULL) {
        fprintf(stderr, "Server: Memory allocation failed.\n");
        goto cleanup;
    }
    printf("Server: Allocated memory for encrypted message.\n");

    // RECEIVE THE ENCRYPTED MESSAGE from client
    if (recv_all(client_sock, encrypted, encrypted_len) != (ssize_t)encrypted_len) {
        fprintf(stderr, "Server: Failed to receive encrypted message.\n");
        goto cleanup;
    }
    printf("Server: Received encrypted message from client.\n");

    // DECRYPT THE ENCRYPTED MESSAGE
    if (!do_decrypt(libctx, encrypted, encrypted_len, &decrypted, &decrypted_len)) {
        fprintf(stderr, "Server: Decryption failed.\n");
        goto cleanup;
    }

    printf("Server: Decrypted message:\n%.*s\n", (int)decrypted_len, decrypted);
    ret = EXIT_SUCCESS;

cleanup:
    if (client_sock >= 0)
        close(client_sock);
    if (server_sock >= 0)
        close(server_sock);
    if (encrypted)
        OPENSSL_free(encrypted);
    if (decrypted)
        OPENSSL_free(decrypted);
    return ret;
}
