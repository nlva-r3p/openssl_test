#include "utils_common.h"

int recv_message(int sockfd, unsigned char **msg, size_t *msg_len, int auto_alloc)
{
    if (auto_alloc) {
        uint32_t net_len = 0;
        // Receive the 32-bit encrypted message length
        if (recv_all(sockfd, &net_len, sizeof(net_len)) != sizeof(net_len)) {
            fprintf(stderr, "Server: Failed to receive message length.\n");
            return -1;
        }
        printf("Server: Received encrypted message length from client.\n");

        // Convert length from network to host byte order and set msg_len
        *msg_len = ntohl(net_len);

        // Allocate memory for the encrypted message
        *msg = OPENSSL_zalloc(*msg_len);
        if (*msg == NULL) {
            fprintf(stderr, "Server: Memory allocation failed.\n");
            return -1;
        }
        printf("Server: Allocated memory for encrypted message.\n");
    }

    // Receive the actual encrypted message data
    if (recv_all(sockfd, *msg, *msg_len) != (ssize_t)*msg_len) {
        fprintf(stderr, "Server: Failed to receive encrypted message.\n");
        if (auto_alloc && *msg != NULL) {
            OPENSSL_free(*msg);
            *msg = NULL;
        }
        return -1;
    }
    printf("Server: Received encrypted message from client.\n");

    return 0;
}
