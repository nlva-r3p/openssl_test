#include <stdio.h>
#include <stdint.h>  // for size_t

#include "net_utils.h"

int recv_message(int sockfd, unsigned char **msg, size_t *msg_len, int auto_alloc);
